package com.zekelabs.kafka;

import java.util.concurrent.ExecutionException;


import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import com.zekelabs.kafka.constants.IKafkaConstants;
import com.zekelabs.kafka.consumer.ConsumerCreator;
import com.zekelabs.kafka.pojo.CustomObject;
import com.zekelabs.kafka.producer.ProducerCreator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.UUID;
import java.util.stream.Stream;

public class App {
	public static void main(String[] args) throws  IOException{
        runProducer();
		runConsumer();
	}

	static void runConsumer() throws  IOException{
		Consumer<Long, String> consumer = ConsumerCreator.createConsumer();

		int noMessageToFetch = 0;

		while (true) {
			final ConsumerRecords<Long, String> consumerRecords = consumer.poll(1000);
			if (consumerRecords.count() == 0) {
				noMessageToFetch++;
				if (noMessageToFetch > IKafkaConstants.MAX_NO_MESSAGE_FOUND_COUNT)
					break;
				else
					continue;
			}
			try {
BufferedWriter bw = new BufferedWriter(new FileWriter ("/home/edyoda/Desktop/Records_output.txt"));
			consumerRecords.forEach(record -> {
				try {
					bw.write(record.value() + System.lineSeparator());
				} catch (IOException e) {
					e.printStackTrace();
				}
				try {
					bw.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("Record Key " + record.key());
				System.out.println("Record value " + record.value());
				//System.out.println("Record value " + record.value().getName());
				System.out.println("Record partition " + record.partition());
				System.out.println("Record offset " + record.offset());
			});
			}
			catch (IOException e) {
				e.printStackTrace();
			} 
			consumer.commitAsync();
		}
		consumer.close();
	}

	
	static void runProducer() throws  IOException{
		Producer<Long, String> producer = ProducerCreator.createProducer();

			try {
				Stream<String> FileStream = Files.lines(Paths.get("/home/edyoda/Desktop/Records.txt"));
	            FileStream.forEach(line -> {
	                final ProducerRecord<Long, String> CsvRecord = new ProducerRecord<Long, String>(
	                		IKafkaConstants.TOPIC_NAME,line);

	                producer.send(CsvRecord, (metadata, exception) -> {
	                    if(metadata != null){
	                        System.out.println("CsvData: -> "+ CsvRecord.key()+" | "+ CsvRecord.value());
	                    }
	                    else{
	                        System.out.println("Error Sending Csv Record -> "+ CsvRecord.value());
	                    }
	                });
	            });


		                }
			 catch (IOException e) {
				e.printStackTrace();
			} 
		
	}
}
